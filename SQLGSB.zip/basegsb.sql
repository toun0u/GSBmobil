-- --------------------------------------------------------
-- Hôte:                         127.0.0.1
-- Version du serveur:           5.7.9 - MySQL Community Server (GPL)
-- Serveur OS:                   Win64
-- HeidiSQL Version:             8.3.0.4694
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Export de la structure de la base pour gsb
CREATE DATABASE IF NOT EXISTS `gsb` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `gsb`;


-- Export de la structure de table gsb. even
CREATE TABLE IF NOT EXISTS `even` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lieu` varchar(25) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  `dateDebut` date DEFAULT NULL,
  `dateFin` date DEFAULT NULL,
  `id_User` int(11) DEFAULT NULL,
  `id_Type` int(11) DEFAULT NULL,
  `heureDebut` varchar(50) DEFAULT NULL,
  `heureFin` varchar(50) DEFAULT NULL,
  `Libelle` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_Event_id_User` (`id_User`),
  KEY `FK_Event_id_Type` (`id_Type`),
  CONSTRAINT `FK_Event_id_Type` FOREIGN KEY (`id_Type`) REFERENCES `type` (`id`),
  CONSTRAINT `FK_Event_id_User` FOREIGN KEY (`id_User`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- Export de données de la table gsb.even: ~4 rows (environ)
DELETE FROM `even`;
/*!40000 ALTER TABLE `even` DISABLE KEYS */;
INSERT INTO `even` (`id`, `lieu`, `description`, `dateDebut`, `dateFin`, `id_User`, `id_Type`, `heureDebut`, `heureFin`, `Libelle`) VALUES
	(1, 'St Malo', 'Venez nombreux', '2015-02-11', '2015-02-11', 1, 1, '12:00', '16:00', 'Réunion1'),
	(2, 'Nantes', 'Amener toute votre famille', '2016-03-09', '2016-03-09', 1, 2, '17:00', '19:00', 'Fetes des Familles'),
	(3, 'Brest', 'DU CIDRE', '2016-03-05', '2016-03-05', 1, 1, '9:00', '14:00', 'Beaujolais nouveau'),
	(4, 'Caen', 'Le spécial Noël !', '2016-12-25', '2016-12-25', 1, 2, '21:00', '2:00', 'Noël de l\'entreprise');
/*!40000 ALTER TABLE `even` ENABLE KEYS */;


-- Export de la structure de table gsb. modification
CREATE TABLE IF NOT EXISTS `modification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `timestampModif` bigint(20) DEFAULT NULL,
  `typeModif` varchar(50) DEFAULT NULL,
  `oldDateDebut` date DEFAULT NULL,
  `oldDateFin` date DEFAULT NULL,
  `id_Event` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_Modification_id_Event` (`id_Event`),
  CONSTRAINT `FK_Modification_id_Event` FOREIGN KEY (`id_Event`) REFERENCES `even` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

-- Export de données de la table gsb.modification: ~28 rows (environ)
DELETE FROM `modification`;
/*!40000 ALTER TABLE `modification` DISABLE KEYS */;
INSERT INTO `modification` (`id`, `timestampModif`, `typeModif`, `oldDateDebut`, `oldDateFin`, `id_Event`) VALUES
	(1, 20160309, 'INSERT', '2015-02-11', '2015-02-11', NULL),
	(2, 20160309, 'INSERT', NULL, NULL, NULL),
	(3, 20160309, 'UPDATE', NULL, NULL, NULL),
	(4, 20160309, 'UPDATE', NULL, NULL, NULL),
	(5, 20160309, 'UPDATE', NULL, '2016-03-09', NULL),
	(6, 20160309, 'UPDATE', '2016-03-09', '2016-03-09', NULL),
	(7, 20160309, 'INSERT', NULL, NULL, NULL),
	(8, 20160309, 'UPDATE', NULL, NULL, NULL),
	(9, 20160309, 'UPDATE', NULL, NULL, NULL),
	(10, 20160309, 'UPDATE', '2016-03-09', NULL, NULL),
	(11, 20160309, 'UPDATE', '2016-03-05', NULL, NULL),
	(12, 20160309, 'UPDATE', '2016-03-05', '2016-03-05', NULL),
	(13, 20160309, 'UPDATE', '2016-03-05', '2016-03-05', NULL),
	(14, 20160309, 'INSERT', NULL, NULL, NULL),
	(15, 20160309, 'UPDATE', NULL, NULL, NULL),
	(16, 20160309, 'UPDATE', NULL, NULL, NULL),
	(17, 20160309, 'UPDATE', '2016-12-25', NULL, NULL),
	(18, 20160309, 'UPDATE', '2016-12-25', '2016-12-25', NULL),
	(19, 20160309, 'UPDATE', '2016-12-25', '2016-12-25', NULL),
	(20, 20160420, 'UPDATE', '2015-02-11', '2015-02-11', NULL),
	(21, 20160420, 'UPDATE', '2016-03-09', '2016-03-09', NULL),
	(22, 20160420, 'UPDATE', '2016-03-05', '2016-03-05', NULL),
	(23, 20160420, 'UPDATE', '2016-12-25', '2016-12-25', NULL),
	(24, 20160426, 'UPDATE', '2015-02-11', '2015-02-11', NULL),
	(25, 20160426, 'UPDATE', '2016-03-09', '2016-03-09', NULL),
	(26, 20160426, 'UPDATE', '2016-03-05', '2016-03-05', NULL),
	(27, 20160426, 'UPDATE', '2016-12-25', '2016-12-25', NULL),
	(28, 20160426, 'UPDATE', '2016-12-25', '2016-12-25', NULL);
/*!40000 ALTER TABLE `modification` ENABLE KEYS */;


-- Export de la structure de table gsb. participer
CREATE TABLE IF NOT EXISTS `participer` (
  `present` tinyint(1) DEFAULT NULL,
  `commentaire` varchar(500) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `id_Event` int(11) NOT NULL,
  PRIMARY KEY (`id`,`id_Event`),
  KEY `FK_participer_id_Event` (`id_Event`),
  CONSTRAINT `FK_participer_id` FOREIGN KEY (`id`) REFERENCES `user` (`id`),
  CONSTRAINT `FK_participer_id_Event` FOREIGN KEY (`id_Event`) REFERENCES `even` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Export de données de la table gsb.participer: ~4 rows (environ)
DELETE FROM `participer`;
/*!40000 ALTER TABLE `participer` DISABLE KEYS */;
INSERT INTO `participer` (`present`, `commentaire`, `id`, `id_Event`) VALUES
	(1, 'Je reste jusque la fin !', 1, 3),
	(1, 'Je suis là jusque 20h', 2, 4),
	(0, 'Flemme', 3, 1),
	(0, 'J\'aime pas les kermesses', 4, 2);
/*!40000 ALTER TABLE `participer` ENABLE KEYS */;


-- Export de la structure de table gsb. service
CREATE TABLE IF NOT EXISTS `service` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `libelle` varchar(50) DEFAULT NULL,
  `id_User` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_Service_id_User` (`id_User`),
  CONSTRAINT `FK_Service_id_User` FOREIGN KEY (`id_User`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Export de données de la table gsb.service: ~2 rows (environ)
DELETE FROM `service`;
/*!40000 ALTER TABLE `service` DISABLE KEYS */;
INSERT INTO `service` (`id`, `libelle`, `id_User`) VALUES
	(1, 'Ventes', 1),
	(2, 'Recherche/Creation', 4);
/*!40000 ALTER TABLE `service` ENABLE KEYS */;


-- Export de la structure de table gsb. type
CREATE TABLE IF NOT EXISTS `type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titre` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Export de données de la table gsb.type: ~2 rows (environ)
DELETE FROM `type`;
/*!40000 ALTER TABLE `type` DISABLE KEYS */;
INSERT INTO `type` (`id`, `titre`) VALUES
	(1, 'Reunion'),
	(2, 'Kermesse');
/*!40000 ALTER TABLE `type` ENABLE KEYS */;


-- Export de la structure de table gsb. user
CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Nom` varchar(50) DEFAULT NULL,
  `Prenom` varchar(50) DEFAULT NULL,
  `Type` varchar(50) DEFAULT NULL,
  `mail` varchar(25) DEFAULT NULL,
  `mdp` varchar(50) DEFAULT NULL,
  `id_Service` int(11) DEFAULT NULL,
  `id_Service_1` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_User_id_Service` (`id_Service`),
  KEY `FK_User_id_Service_1` (`id_Service_1`),
  CONSTRAINT `FK_User_id_Service` FOREIGN KEY (`id_Service`) REFERENCES `service` (`id`),
  CONSTRAINT `FK_User_id_Service_1` FOREIGN KEY (`id_Service_1`) REFERENCES `service` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- Export de données de la table gsb.user: ~4 rows (environ)
DELETE FROM `user`;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` (`id`, `Nom`, `Prenom`, `Type`, `mail`, `mdp`, `id_Service`, `id_Service_1`) VALUES
	(1, 'Toto', 'Depuis', 'admin', 'totodepuis@gmail.com', 'azerty', 1, 1),
	(2, 'Bob', 'Yi', 'salarie', 'bobyi@orange.fr', 'bobmdp', 1, 1),
	(3, 'Francky', 'Snow', 'salarie', 'snow.francky@wanadoo.com', 'rollersurfer', 2, 2),
	(4, 'Barbara', 'Despontie', 'admin', 'despontiebarbara@free.fr', 'poiuytreza', 2, 2),
	(5, 'NAUDIN', 'Benjamin', 'DEV', 'benjamin.naudin@free.fr', 'azerty', 1, 2);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;


-- Export de la structure de déclancheur gsb. TG_DEL_EV
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_ALL_TABLES,NO_AUTO_CREATE_USER';
DELIMITER //
CREATE TRIGGER `TG_DEL_EV` BEFORE DELETE ON `even` FOR EACH ROW begin 
	insert into modification(timestampModif, typeModif, oldDateDebut, oldDateFin) values(current_date(), 'DELETE', old.dateDebut, old.dateFin);
end//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;


-- Export de la structure de déclancheur gsb. TG_INS_EV
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_ALL_TABLES,NO_AUTO_CREATE_USER';
DELIMITER //
CREATE TRIGGER `TG_INS_EV` BEFORE INSERT ON `even` FOR EACH ROW begin 
	insert into modification(timestampModif, typeModif, oldDateDebut, oldDateFin) values(current_date(), 'INSERT', new.dateDebut, new.dateFin);
end//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;


-- Export de la structure de déclancheur gsb. TG_MOD_EV
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_ALL_TABLES,NO_AUTO_CREATE_USER';
DELIMITER //
CREATE TRIGGER `TG_MOD_EV` BEFORE UPDATE ON `even` FOR EACH ROW begin 
	insert into modification(timestampModif, typeModif, oldDateDebut, oldDateFin) values(current_date(), 'UPDATE', old.dateDebut, old.dateFin);
end//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
